public class MatrixTestObject extends MatrixTest<Object> {
	
	public Object getParameterInstance() {
		return new Object();
	}

}

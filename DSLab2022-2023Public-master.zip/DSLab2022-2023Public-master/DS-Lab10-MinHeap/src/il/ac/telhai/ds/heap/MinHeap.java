package il.ac.telhai.ds.heap;

public class MinHeap<T extends Comparable<T>> {

	public MinHeap(int length) {
		// TODO add your implementation here
	}

	public MinHeap(T[] arr) {
		// TODO add your implementation here
	}

	public boolean isFull() {
		// TODO add your implementation here
	}

	public boolean isEmpty() {
		// TODO add your implementation here
	}

	public void insert(T element) {
		// TODO add your implementation here
	}

	public T getMin() {
		// TODO add your implementation here
	}

	public T deleteMin() {
		// TODO add your implementation here
	}

	/**
	 * return a string represents the heap. The order of the elements are according
	 * to The string starts with "[", ends with "]", and the values are seperated
	 * with a comma
	 */
	public String toString() {
		// TODO add your implementation here
	}
}

public class ListTestInteger extends ListTest<Integer>{
	@Override
	public Integer getParameterInstance() {
		//TODO add your implementation
	}

}

import org.junit.Before;

public class TimerTest {
	
	private Timer t;

	@Before
	public void setUp() throws Exception {
		t = UtilsLab03.TimerFactory.getTimer();
	}
	
	//Add @Test methods 

}
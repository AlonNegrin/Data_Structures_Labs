public class Timer {

	// Precondition: There timer is not active.
	// Postcondition: Marks the beginning of a time interval (starts the timer).
	public void start() {
	//TODO
	}

	// Precondition: The beginning of a time interval has been marked (-the timer is active).
	// Postcondition: Marks the end of a time interval (stops the timer).
	public void stop() {
		//TODO
	}

	// Precondition: The beginning and end of a time interval have been marked.
	// Postcondition: Returns the length of the time interval in milliseconds.
	public long elapsedTime() {
		//TODO
	}
	
	
}